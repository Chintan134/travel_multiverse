module.exports = [
"[project]/styles/Home.module.css [ssr] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "continueButton": "Home-module__g21JLG__continueButton",
  "creativeContinueButton": "Home-module__g21JLG__creativeContinueButton",
  "creativeCtaRow": "Home-module__g21JLG__creativeCtaRow",
  "creativeFlavorCard": "Home-module__g21JLG__creativeFlavorCard",
  "creativeFlavorCardActive": "Home-module__g21JLG__creativeFlavorCardActive",
  "creativeFlavorCardInactive": "Home-module__g21JLG__creativeFlavorCardInactive",
  "creativeFlavorDescription": "Home-module__g21JLG__creativeFlavorDescription",
  "creativeFlavorIcon": "Home-module__g21JLG__creativeFlavorIcon",
  "creativeFlavorText": "Home-module__g21JLG__creativeFlavorText",
  "creativeFlavorTitle": "Home-module__g21JLG__creativeFlavorTitle",
  "creativeFlavorsGrid": "Home-module__g21JLG__creativeFlavorsGrid",
  "creativeFlavorsHeader": "Home-module__g21JLG__creativeFlavorsHeader",
  "creativeFlavorsRow": "Home-module__g21JLG__creativeFlavorsRow",
  "creativeFlavorsSubtitle": "Home-module__g21JLG__creativeFlavorsSubtitle",
  "creativeFlavorsTitle": "Home-module__g21JLG__creativeFlavorsTitle",
  "creativeSelectedText": "Home-module__g21JLG__creativeSelectedText",
  "flavorDetailChip": "Home-module__g21JLG__flavorDetailChip",
  "flavorDetailChipActive": "Home-module__g21JLG__flavorDetailChipActive",
  "flavorDetailChipInactive": "Home-module__g21JLG__flavorDetailChipInactive",
  "flavorDetailChips": "Home-module__g21JLG__flavorDetailChips",
  "flavorDetailFileInput": "Home-module__g21JLG__flavorDetailFileInput",
  "flavorDetailHeader": "Home-module__g21JLG__flavorDetailHeader",
  "flavorDetailHint": "Home-module__g21JLG__flavorDetailHint",
  "flavorDetailInfo": "Home-module__g21JLG__flavorDetailInfo",
  "flavorDetailPanel": "Home-module__g21JLG__flavorDetailPanel",
  "flavorDetailSubtitle": "Home-module__g21JLG__flavorDetailSubtitle",
  "flavorDetailTitle": "Home-module__g21JLG__flavorDetailTitle",
  "flavorDetailUpload": "Home-module__g21JLG__flavorDetailUpload",
  "header": "Home-module__g21JLG__header",
  "headerTagline": "Home-module__g21JLG__headerTagline",
  "hero": "Home-module__g21JLG__hero",
  "heroButton": "Home-module__g21JLG__heroButton",
  "heroContent": "Home-module__g21JLG__heroContent",
  "heroNote": "Home-module__g21JLG__heroNote",
  "heroOverlay": "Home-module__g21JLG__heroOverlay",
  "heroSubline": "Home-module__g21JLG__heroSubline",
  "heroTagline": "Home-module__g21JLG__heroTagline",
  "heroTitle": "Home-module__g21JLG__heroTitle",
  "itineraryDay": "Home-module__g21JLG__itineraryDay",
  "itineraryDayMarker": "Home-module__g21JLG__itineraryDayMarker",
  "itineraryDayTitle": "Home-module__g21JLG__itineraryDayTitle",
  "itineraryItem": "Home-module__g21JLG__itineraryItem",
  "itineraryItemList": "Home-module__g21JLG__itineraryItemList",
  "logo": "Home-module__g21JLG__logo",
  "logoWrapper": "Home-module__g21JLG__logoWrapper",
  "multiverseTab": "Home-module__g21JLG__multiverseTab",
  "multiverseTabActive": "Home-module__g21JLG__multiverseTabActive",
  "multiverseTabs": "Home-module__g21JLG__multiverseTabs",
  "page": "Home-module__g21JLG__page",
  "summaryActions": "Home-module__g21JLG__summaryActions",
  "summaryButtonGhost": "Home-module__g21JLG__summaryButtonGhost",
  "summaryButtonPrimary": "Home-module__g21JLG__summaryButtonPrimary",
  "summaryButtonSecondary": "Home-module__g21JLG__summaryButtonSecondary",
  "summaryCard": "Home-module__g21JLG__summaryCard",
  "summaryCardTitle": "Home-module__g21JLG__summaryCardTitle",
  "summaryGrid": "Home-module__g21JLG__summaryGrid",
  "summaryHero": "Home-module__g21JLG__summaryHero",
  "summaryHeroChip": "Home-module__g21JLG__summaryHeroChip",
  "summaryHeroChips": "Home-module__g21JLG__summaryHeroChips",
  "summaryHeroContent": "Home-module__g21JLG__summaryHeroContent",
  "summaryHeroOverlay": "Home-module__g21JLG__summaryHeroOverlay",
  "summaryHeroQuote": "Home-module__g21JLG__summaryHeroQuote",
  "summaryHeroTagline": "Home-module__g21JLG__summaryHeroTagline",
  "summaryHeroTitle": "Home-module__g21JLG__summaryHeroTitle",
  "summaryIntro": "Home-module__g21JLG__summaryIntro",
  "summaryItineraryCard": "Home-module__g21JLG__summaryItineraryCard",
  "summaryModeStrip": "Home-module__g21JLG__summaryModeStrip",
  "summaryModeStripLabel": "Home-module__g21JLG__summaryModeStripLabel",
  "summaryModeStripText": "Home-module__g21JLG__summaryModeStripText",
  "summaryTimelineTitle": "Home-module__g21JLG__summaryTimelineTitle",
  "tripBackLink": "Home-module__g21JLG__tripBackLink",
  "tripBackRow": "Home-module__g21JLG__tripBackRow",
  "tripBadge": "Home-module__g21JLG__tripBadge",
  "tripButtonPrimary": "Home-module__g21JLG__tripButtonPrimary",
  "tripButtonSecondary": "Home-module__g21JLG__tripButtonSecondary",
  "tripCard": "Home-module__g21JLG__tripCard",
  "tripCardActive": "Home-module__g21JLG__tripCardActive",
  "tripCardHeaderRow": "Home-module__g21JLG__tripCardHeaderRow",
  "tripCardInactive": "Home-module__g21JLG__tripCardInactive",
  "tripCardSubtitle": "Home-module__g21JLG__tripCardSubtitle",
  "tripCardTitle": "Home-module__g21JLG__tripCardTitle",
  "tripContainer": "Home-module__g21JLG__tripContainer",
  "tripFieldGroup": "Home-module__g21JLG__tripFieldGroup",
  "tripFormGrid": "Home-module__g21JLG__tripFormGrid",
  "tripHint": "Home-module__g21JLG__tripHint",
  "tripInput": "Home-module__g21JLG__tripInput",
  "tripLabel": "Home-module__g21JLG__tripLabel",
  "tripMain": "Home-module__g21JLG__tripMain",
  "tripNote": "Home-module__g21JLG__tripNote",
  "tripOptionsLayout": "Home-module__g21JLG__tripOptionsLayout",
  "tripSelect": "Home-module__g21JLG__tripSelect",
  "tripSubtitle": "Home-module__g21JLG__tripSubtitle",
  "tripTextarea": "Home-module__g21JLG__tripTextarea",
  "tripTitle": "Home-module__g21JLG__tripTitle",
  "video": "Home-module__g21JLG__video",
  "videoDescription": "Home-module__g21JLG__videoDescription",
  "videoEyebrow": "Home-module__g21JLG__videoEyebrow",
  "videoSection": "Home-module__g21JLG__videoSection",
  "videoText": "Home-module__g21JLG__videoText",
  "videoTitle": "Home-module__g21JLG__videoTitle",
  "videoWrapper": "Home-module__g21JLG__videoWrapper",
});
}),
"[project]/pages/creative-modes.js [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CreativeModes
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/styles/Home.module.css [ssr] (css module)");
;
;
;
function CreativeModes() {
    const modes = [
        {
            id: 1,
            name: "Flavors",
            description: "Pick a flavor dimension, then select a subtype to customize your multiverse vibe.",
            type: "flavors"
        },
        {
            id: 2,
            name: "Custom Input",
            description: "Describe your dream universe, specify details, or share wild imagination!",
            type: "input"
        },
        {
            id: 3,
            name: "Photo Upload",
            description: "Upload an image as a seed for generating a personalized universe.",
            type: "upload"
        },
        {
            id: 4,
            name: "Advanced Theme Builder",
            description: "Choose from templates or build your own theme using dynamic controls.",
            type: "advanced"
        }
    ];
    const flavors = [
        {
            id: "vibe",
            name: "Vibe Spectrum",
            type: "flavor-type",
            subtypes: [
                "Calm & Serene",
                "Energetic & Vibrant",
                "Dark & Mystical",
                "Playful & Dreamy"
            ]
        },
        {
            id: "era",
            name: "Era Selector",
            type: "flavor-type",
            subtypes: [
                "Prehistoric Age",
                "Medieval Kingdom",
                "Cyberpunk Future",
                "Galactic Era"
            ]
        },
        {
            id: "theme",
            name: "Core Theme",
            type: "flavor-type",
            subtypes: [
                "Romantic Universe",
                "Adventure Universe",
                "Sci-Fi Universe",
                "Spiritual Universe"
            ]
        }
    ];
    const [selectedMode, setSelectedMode] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(null);
    const [selectedFlavor, setSelectedFlavor] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(null);
    const [selectedDetail, setSelectedDetail] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(null);
    const [textInput, setTextInput] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])("");
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].pageWrapper,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h1", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].pageTitle,
                children: "Choose Your Creative Mode"
            }, void 0, false, {
                fileName: "[project]/pages/creative-modes.js",
                lineNumber: 79,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].modeGrid,
                children: modes.map((mode)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].modeCard} ${selectedMode === mode.type ? __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].modeCardActive : ""}`,
                        onClick: ()=>{
                            setSelectedMode(mode.type);
                            setSelectedFlavor(null);
                            setSelectedDetail(null);
                            setTextInput("");
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h2", {
                                children: mode.name
                            }, void 0, false, {
                                fileName: "[project]/pages/creative-modes.js",
                                lineNumber: 96,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                children: mode.description
                            }, void 0, false, {
                                fileName: "[project]/pages/creative-modes.js",
                                lineNumber: 97,
                                columnNumber: 13
                            }, this)
                        ]
                    }, mode.id, true, {
                        fileName: "[project]/pages/creative-modes.js",
                        lineNumber: 84,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/pages/creative-modes.js",
                lineNumber: 82,
                columnNumber: 7
            }, this),
            selectedMode && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].detailSection,
                children: [
                    selectedMode === "flavors" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].flavorGrid,
                        children: flavors.map((flavor)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].flavorCard} ${selectedFlavor?.id === flavor.id ? __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].flavorCardActive : ""}`,
                                onClick: ()=>{
                                    setSelectedFlavor(flavor);
                                    setSelectedDetail(null);
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h3", {
                                    children: flavor.name
                                }, void 0, false, {
                                    fileName: "[project]/pages/creative-modes.js",
                                    lineNumber: 121,
                                    columnNumber: 19
                                }, this)
                            }, flavor.id, false, {
                                fileName: "[project]/pages/creative-modes.js",
                                lineNumber: 109,
                                columnNumber: 17
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/pages/creative-modes.js",
                        lineNumber: 107,
                        columnNumber: 13
                    }, this),
                    selectedFlavor && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].subtypeList,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h3", {
                                children: "Select a Subtype"
                            }, void 0, false, {
                                fileName: "[project]/pages/creative-modes.js",
                                lineNumber: 130,
                                columnNumber: 15
                            }, this),
                            selectedFlavor.subtypes.map((sub, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].subtypeItem} ${selectedDetail === sub ? __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].subtypeItemActive : ""}`,
                                    onClick: ()=>setSelectedDetail(sub),
                                    children: sub
                                }, idx, false, {
                                    fileName: "[project]/pages/creative-modes.js",
                                    lineNumber: 132,
                                    columnNumber: 17
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/pages/creative-modes.js",
                        lineNumber: 129,
                        columnNumber: 13
                    }, this),
                    selectedMode === "input" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].inputBlock,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("textarea", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].textArea,
                            placeholder: "Describe your universe…",
                            value: textInput,
                            onChange: (e)=>setTextInput(e.target.value)
                        }, void 0, false, {
                            fileName: "[project]/pages/creative-modes.js",
                            lineNumber: 148,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/pages/creative-modes.js",
                        lineNumber: 147,
                        columnNumber: 13
                    }, this),
                    selectedMode === "upload" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].uploadBlock,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h3", {
                                children: "Upload an Image"
                            }, void 0, false, {
                                fileName: "[project]/pages/creative-modes.js",
                                lineNumber: 160,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                children: "This image will be used as a seed for universe generation."
                            }, void 0, false, {
                                fileName: "[project]/pages/creative-modes.js",
                                lineNumber: 161,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("input", {
                                type: "file",
                                accept: ".jpg,.jpeg,.png",
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].uploadInput,
                                onChange: (e)=>{
                                    const file = e.target.files?.[0];
                                    if (!file) return setSelectedDetail(null);
                                    const valid = [
                                        "image/jpeg",
                                        "image/png"
                                    ].includes(file.type) || /\.(jpg|jpeg|png)$/i.test(file.name);
                                    if (!valid) {
                                        alert("Please upload a JPG or PNG image.");
                                        e.target.value = "";
                                        return setSelectedDetail(null);
                                    }
                                    setSelectedDetail(file.name);
                                }
                            }, void 0, false, {
                                fileName: "[project]/pages/creative-modes.js",
                                lineNumber: 164,
                                columnNumber: 15
                            }, this),
                            selectedDetail && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].uploadFileName,
                                children: [
                                    "Selected: ",
                                    selectedDetail
                                ]
                            }, void 0, true, {
                                fileName: "[project]/pages/creative-modes.js",
                                lineNumber: 187,
                                columnNumber: 17
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/pages/creative-modes.js",
                        lineNumber: 159,
                        columnNumber: 13
                    }, this),
                    selectedMode === "advanced" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].advancedBlock,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h3", {
                                children: "Advanced Theme Builder"
                            }, void 0, false, {
                                fileName: "[project]/pages/creative-modes.js",
                                lineNumber: 195,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                children: "Coming soon — dynamic sliders, palette control, and templates!"
                            }, void 0, false, {
                                fileName: "[project]/pages/creative-modes.js",
                                lineNumber: 196,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/pages/creative-modes.js",
                        lineNumber: 194,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/pages/creative-modes.js",
                lineNumber: 104,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/pages/creative-modes.js",
        lineNumber: 78,
        columnNumber: 5
    }, this);
}
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__457ef39c._.js.map