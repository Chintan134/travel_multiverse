module.exports = [
"[project]/styles/Home.module.css [ssr] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "continueButton": "Home-module__g21JLG__continueButton",
  "creativeContinueButton": "Home-module__g21JLG__creativeContinueButton",
  "creativeCtaRow": "Home-module__g21JLG__creativeCtaRow",
  "creativeFlavorCard": "Home-module__g21JLG__creativeFlavorCard",
  "creativeFlavorCardActive": "Home-module__g21JLG__creativeFlavorCardActive",
  "creativeFlavorCardInactive": "Home-module__g21JLG__creativeFlavorCardInactive",
  "creativeFlavorDescription": "Home-module__g21JLG__creativeFlavorDescription",
  "creativeFlavorIcon": "Home-module__g21JLG__creativeFlavorIcon",
  "creativeFlavorText": "Home-module__g21JLG__creativeFlavorText",
  "creativeFlavorTitle": "Home-module__g21JLG__creativeFlavorTitle",
  "creativeFlavorsGrid": "Home-module__g21JLG__creativeFlavorsGrid",
  "creativeFlavorsHeader": "Home-module__g21JLG__creativeFlavorsHeader",
  "creativeFlavorsRow": "Home-module__g21JLG__creativeFlavorsRow",
  "creativeFlavorsSubtitle": "Home-module__g21JLG__creativeFlavorsSubtitle",
  "creativeFlavorsTitle": "Home-module__g21JLG__creativeFlavorsTitle",
  "creativeSelectedText": "Home-module__g21JLG__creativeSelectedText",
  "flavorDetailChip": "Home-module__g21JLG__flavorDetailChip",
  "flavorDetailChipActive": "Home-module__g21JLG__flavorDetailChipActive",
  "flavorDetailChipInactive": "Home-module__g21JLG__flavorDetailChipInactive",
  "flavorDetailChips": "Home-module__g21JLG__flavorDetailChips",
  "flavorDetailFileInput": "Home-module__g21JLG__flavorDetailFileInput",
  "flavorDetailHeader": "Home-module__g21JLG__flavorDetailHeader",
  "flavorDetailHint": "Home-module__g21JLG__flavorDetailHint",
  "flavorDetailInfo": "Home-module__g21JLG__flavorDetailInfo",
  "flavorDetailPanel": "Home-module__g21JLG__flavorDetailPanel",
  "flavorDetailSubtitle": "Home-module__g21JLG__flavorDetailSubtitle",
  "flavorDetailTitle": "Home-module__g21JLG__flavorDetailTitle",
  "flavorDetailUpload": "Home-module__g21JLG__flavorDetailUpload",
  "header": "Home-module__g21JLG__header",
  "headerTagline": "Home-module__g21JLG__headerTagline",
  "hero": "Home-module__g21JLG__hero",
  "heroButton": "Home-module__g21JLG__heroButton",
  "heroContent": "Home-module__g21JLG__heroContent",
  "heroNote": "Home-module__g21JLG__heroNote",
  "heroOverlay": "Home-module__g21JLG__heroOverlay",
  "heroSubline": "Home-module__g21JLG__heroSubline",
  "heroTagline": "Home-module__g21JLG__heroTagline",
  "heroTitle": "Home-module__g21JLG__heroTitle",
  "itineraryDay": "Home-module__g21JLG__itineraryDay",
  "itineraryDayMarker": "Home-module__g21JLG__itineraryDayMarker",
  "itineraryDayTitle": "Home-module__g21JLG__itineraryDayTitle",
  "itineraryItem": "Home-module__g21JLG__itineraryItem",
  "itineraryItemList": "Home-module__g21JLG__itineraryItemList",
  "logo": "Home-module__g21JLG__logo",
  "logoWrapper": "Home-module__g21JLG__logoWrapper",
  "multiverseTab": "Home-module__g21JLG__multiverseTab",
  "multiverseTabActive": "Home-module__g21JLG__multiverseTabActive",
  "multiverseTabs": "Home-module__g21JLG__multiverseTabs",
  "page": "Home-module__g21JLG__page",
  "summaryActions": "Home-module__g21JLG__summaryActions",
  "summaryButtonGhost": "Home-module__g21JLG__summaryButtonGhost",
  "summaryButtonPrimary": "Home-module__g21JLG__summaryButtonPrimary",
  "summaryButtonSecondary": "Home-module__g21JLG__summaryButtonSecondary",
  "summaryCard": "Home-module__g21JLG__summaryCard",
  "summaryCardTitle": "Home-module__g21JLG__summaryCardTitle",
  "summaryGrid": "Home-module__g21JLG__summaryGrid",
  "summaryHero": "Home-module__g21JLG__summaryHero",
  "summaryHeroChip": "Home-module__g21JLG__summaryHeroChip",
  "summaryHeroChips": "Home-module__g21JLG__summaryHeroChips",
  "summaryHeroContent": "Home-module__g21JLG__summaryHeroContent",
  "summaryHeroOverlay": "Home-module__g21JLG__summaryHeroOverlay",
  "summaryHeroQuote": "Home-module__g21JLG__summaryHeroQuote",
  "summaryHeroTagline": "Home-module__g21JLG__summaryHeroTagline",
  "summaryHeroTitle": "Home-module__g21JLG__summaryHeroTitle",
  "summaryIntro": "Home-module__g21JLG__summaryIntro",
  "summaryItineraryCard": "Home-module__g21JLG__summaryItineraryCard",
  "summaryModeStrip": "Home-module__g21JLG__summaryModeStrip",
  "summaryModeStripLabel": "Home-module__g21JLG__summaryModeStripLabel",
  "summaryModeStripText": "Home-module__g21JLG__summaryModeStripText",
  "summaryTimelineTitle": "Home-module__g21JLG__summaryTimelineTitle",
  "tripBackLink": "Home-module__g21JLG__tripBackLink",
  "tripBackRow": "Home-module__g21JLG__tripBackRow",
  "tripBadge": "Home-module__g21JLG__tripBadge",
  "tripButtonPrimary": "Home-module__g21JLG__tripButtonPrimary",
  "tripButtonSecondary": "Home-module__g21JLG__tripButtonSecondary",
  "tripCard": "Home-module__g21JLG__tripCard",
  "tripCardActive": "Home-module__g21JLG__tripCardActive",
  "tripCardHeaderRow": "Home-module__g21JLG__tripCardHeaderRow",
  "tripCardInactive": "Home-module__g21JLG__tripCardInactive",
  "tripCardSubtitle": "Home-module__g21JLG__tripCardSubtitle",
  "tripCardTitle": "Home-module__g21JLG__tripCardTitle",
  "tripContainer": "Home-module__g21JLG__tripContainer",
  "tripFieldGroup": "Home-module__g21JLG__tripFieldGroup",
  "tripFormGrid": "Home-module__g21JLG__tripFormGrid",
  "tripHint": "Home-module__g21JLG__tripHint",
  "tripInput": "Home-module__g21JLG__tripInput",
  "tripLabel": "Home-module__g21JLG__tripLabel",
  "tripMain": "Home-module__g21JLG__tripMain",
  "tripNote": "Home-module__g21JLG__tripNote",
  "tripOptionsLayout": "Home-module__g21JLG__tripOptionsLayout",
  "tripSelect": "Home-module__g21JLG__tripSelect",
  "tripSubtitle": "Home-module__g21JLG__tripSubtitle",
  "tripTextarea": "Home-module__g21JLG__tripTextarea",
  "tripTitle": "Home-module__g21JLG__tripTitle",
  "video": "Home-module__g21JLG__video",
  "videoDescription": "Home-module__g21JLG__videoDescription",
  "videoEyebrow": "Home-module__g21JLG__videoEyebrow",
  "videoSection": "Home-module__g21JLG__videoSection",
  "videoText": "Home-module__g21JLG__videoText",
  "videoTitle": "Home-module__g21JLG__videoTitle",
  "videoWrapper": "Home-module__g21JLG__videoWrapper",
});
}),
"[project]/pages/index.js [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Home
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$head$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/head.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/link.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/styles/Home.module.css [ssr] (css module)");
;
;
;
;
;
// Hero slideshow images in /public
const HERO_IMAGES = [
    "/hero1.jpg",
    "/hero2.jpg",
    "/hero3.jpg",
    "/hero4.jpg"
];
function Home() {
    const [currentIndex, setCurrentIndex] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(0);
    // Auto-change hero background every 6 seconds
    (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useEffect"])(()=>{
        if (HERO_IMAGES.length <= 1) return;
        const interval = setInterval(()=>setCurrentIndex((prev)=>(prev + 1) % HERO_IMAGES.length), 6000);
        return ()=>clearInterval(interval);
    }, []);
    const currentImage = HERO_IMAGES[currentIndex];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].page,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$head$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("title", {
                        children: "Travel Multiverse"
                    }, void 0, false, {
                        fileName: "[project]/pages/index.js",
                        lineNumber: 28,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("meta", {
                        name: "description",
                        content: "Turn your mood, imagination, or even a photo into a travel itinerary."
                    }, void 0, false, {
                        fileName: "[project]/pages/index.js",
                        lineNumber: 29,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/pages/index.js",
                lineNumber: 27,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("main", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("section", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].hero,
                        style: {
                            backgroundImage: `url(${currentImage})`
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].heroOverlay
                            }, void 0, false, {
                                fileName: "[project]/pages/index.js",
                                lineNumber: 41,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].heroContent,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h1", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].heroTitle,
                                        children: "TRAVEL MULTIVERSE"
                                    }, void 0, false, {
                                        fileName: "[project]/pages/index.js",
                                        lineNumber: 43,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].heroTagline,
                                        children: "Turn your mood, imagination, or even a photo into a travel itinerary."
                                    }, void 0, false, {
                                        fileName: "[project]/pages/index.js",
                                        lineNumber: 45,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].heroSubline,
                                        children: "Where your emotions turn into paths. Where your imagination becomes a map."
                                    }, void 0, false, {
                                        fileName: "[project]/pages/index.js",
                                        lineNumber: 49,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        href: "/trip-details",
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].heroButton,
                                        children: "Start Your Journey"
                                    }, void 0, false, {
                                        fileName: "[project]/pages/index.js",
                                        lineNumber: 53,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].heroNote,
                                        children: "No login needed — just wander."
                                    }, void 0, false, {
                                        fileName: "[project]/pages/index.js",
                                        lineNumber: 57,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/pages/index.js",
                                lineNumber: 42,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/pages/index.js",
                        lineNumber: 37,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("section", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].videoSection,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].videoText,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h2", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].videoEyebrow,
                                        children: "JUST ADD MAGIC"
                                    }, void 0, false, {
                                        fileName: "[project]/pages/index.js",
                                        lineNumber: 64,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h3", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].videoTitle,
                                        children: "Travel Mascot Animation"
                                    }, void 0, false, {
                                        fileName: "[project]/pages/index.js",
                                        lineNumber: 65,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].videoDescription,
                                        children: "Your travel mascot brings the multiverse to life with subtle motion, capturing the calm, inspiring feeling of stepping into a dream destination."
                                    }, void 0, false, {
                                        fileName: "[project]/pages/index.js",
                                        lineNumber: 66,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/pages/index.js",
                                lineNumber: 63,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].videoWrapper,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("video", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].video,
                                    src: "/mascot.mp4",
                                    controls: true,
                                    playsInline: true,
                                    poster: "/video-poster.jpg"
                                }, void 0, false, {
                                    fileName: "[project]/pages/index.js",
                                    lineNumber: 74,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/pages/index.js",
                                lineNumber: 73,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/pages/index.js",
                        lineNumber: 62,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/pages/index.js",
                lineNumber: 35,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/pages/index.js",
        lineNumber: 26,
        columnNumber: 5
    }, this);
}
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__fa27a54e._.js.map