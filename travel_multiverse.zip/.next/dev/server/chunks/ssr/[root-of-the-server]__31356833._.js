module.exports = [
"[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("react/jsx-dev-runtime", () => require("react/jsx-dev-runtime"));

module.exports = mod;
}),
"[externals]/react [external] (react, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("react", () => require("react"));

module.exports = mod;
}),
"[project]/utils/generator.js [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "generateTrip",
    ()=>generateTrip
]);
function generateTrip(trip) {
    const { destination, days, budget, companion, mode, mood, persona } = trip;
    const safeDestination = destination || "Your Dream Place";
    const safeDays = days || 3;
    // Very simple hero selection
    const heroImage = "/hero-placeholder.jpg"; // you can replace later
    const baseItinerary = Array.from({
        length: safeDays
    }).map((_, i)=>({
            dayNumber: i + 1,
            items: [
                `Slow morning exploring the heart of ${safeDestination}.`,
                `Discover a hidden local gem in the afternoon.`,
                `Evening reflection with a beautiful view.`
            ]
        }));
    let notes = "";
    let multiverseData = null;
    switch(mode){
        case "vibetrip":
            notes = `Your mood was "${mood || "Curious"}", so this trip focuses on discovery, gentle surprises, and hidden corners.`;
            break;
        case "parallel":
            notes = `You are traveling as "${persona || "Adventurer Me"}", so the experiences lean into that identity with bolder choices and deeper immersion.`;
            break;
        case "onephoto":
            notes = "This itinerary is inspired by the colors and emotion of your photo — translated into landscapes, streets, and moments.";
            break;
        case "multiverse":
            notes = "Explore the Real, Dream, and Vibe versions of this journey — three parallel ways to live the same destination.";
            multiverseData = {
                realistic: {
                    title: "Realistic",
                    items: [
                        `Grounded, budget-conscious experiences in ${safeDestination}.`,
                        "Classic sights, relaxed pacing, and local comfort food."
                    ]
                },
                dream: {
                    title: "Dream",
                    items: [
                        `Luxury views, curated stays, and premium experiences in ${safeDestination}.`,
                        "Massage, fine dining, and once-in-a-lifetime moments."
                    ]
                },
                vibe: {
                    title: "Vibe",
                    items: [
                        `Aesthetic corners, photogenic streets, and mood-rich places in ${safeDestination}.`,
                        "Sunsets, cozy cafés, and reflective walks."
                    ]
                }
            };
            break;
        case "anti":
            notes = "This flow is intentionally loose. Let the city surprise you — follow your curiosity instead of the schedule.";
            break;
        case "classic":
        default:
            notes = "A grounded, realistic itinerary based on your inputs — flexible enough for you to personalize on the go.";
            break;
    }
    // Slightly tweak base itinerary per mode
    const itinerary = baseItinerary.map((day)=>{
        const extra = mode === "vibetrip" ? " Pause for a mindful moment and notice how the place makes you feel." : mode === "parallel" ? " Ask yourself: how would this version of you choose to spend this hour?" : mode === "anti" ? " Leave one key part of this day unplanned, on purpose." : "";
        return {
            ...day,
            items: day.items.map((item)=>item + extra)
        };
    });
    return {
        heroImage,
        itinerary,
        notes,
        multiverseData
    };
}
}),
"[project]/context/TripContext.jsx [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TripProvider",
    ()=>TripProvider,
    "useTrip",
    ()=>useTrip
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$generator$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/utils/generator.js [ssr] (ecmascript)");
;
;
;
const TripContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["createContext"])(null);
const TripProvider = ({ children })=>{
    const [trip, setTrip] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])({
        destination: "",
        days: "",
        companion: "",
        budget: "",
        freeformInput: "",
        inputMethod: "structured",
        mode: "",
        mood: "",
        persona: "",
        uploadedPhoto: null,
        heroImage: "",
        itinerary: [],
        notes: "",
        multiverseData: null
    });
    const updateTripDetails = (partial)=>{
        setTrip((prev)=>({
                ...prev,
                ...partial
            }));
    };
    const regenerateTrip = ()=>{
        const generated = (0, __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$generator$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["generateTrip"])(trip);
        setTrip((prev)=>({
                ...prev,
                ...generated
            }));
    };
    const resetTrip = ()=>{
        setTrip({
            destination: "",
            days: "",
            companion: "",
            budget: "",
            freeformInput: "",
            inputMethod: "structured",
            mode: "",
            mood: "",
            persona: "",
            uploadedPhoto: null,
            heroImage: "",
            itinerary: [],
            notes: "",
            multiverseData: null
        });
    };
    const value = {
        trip,
        updateTripDetails,
        regenerateTrip,
        resetTrip
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(TripContext.Provider, {
        value: value,
        children: children
    }, void 0, false, {
        fileName: "[project]/context/TripContext.jsx",
        lineNumber: 62,
        columnNumber: 10
    }, ("TURBOPACK compile-time value", void 0));
};
const useTrip = ()=>(0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useContext"])(TripContext);
}),
"[project]/components/Layout.jsx [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
;
const Layout = ({ children })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-cloud",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("header", {
                className: "border-b border-beige/80 bg-white/70 backdrop-blur",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                    className: "page-container flex items-center justify-between py-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                            className: "font-heading text-xl font-semibold text-stone",
                            children: [
                                "Travel ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                    className: "text-ocean",
                                    children: "Multiverse"
                                }, void 0, false, {
                                    fileName: "[project]/components/Layout.jsx",
                                    lineNumber: 7,
                                    columnNumber: 20
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/Layout.jsx",
                            lineNumber: 6,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                            className: "hidden text-sm text-fog md:block",
                            children: "Where your emotions become itineraries."
                        }, void 0, false, {
                            fileName: "[project]/components/Layout.jsx",
                            lineNumber: 9,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/Layout.jsx",
                    lineNumber: 5,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/components/Layout.jsx",
                lineNumber: 4,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("main", {
                className: "page-container",
                children: children
            }, void 0, false, {
                fileName: "[project]/components/Layout.jsx",
                lineNumber: 14,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/components/Layout.jsx",
        lineNumber: 3,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = Layout;
}),
"[project]/pages/_app.js [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$context$2f$TripContext$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/context/TripContext.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Layout$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Layout.jsx [ssr] (ecmascript)");
;
;
;
;
function MyApp({ Component, pageProps }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$context$2f$TripContext$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["TripProvider"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Layout$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(Component, {
                ...pageProps
            }, void 0, false, {
                fileName: "[project]/pages/_app.js",
                lineNumber: 9,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/pages/_app.js",
            lineNumber: 8,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/pages/_app.js",
        lineNumber: 7,
        columnNumber: 5
    }, this);
}
const __TURBOPACK__default__export__ = MyApp;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__31356833._.js.map