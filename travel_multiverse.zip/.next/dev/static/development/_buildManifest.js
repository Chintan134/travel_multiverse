self.__BUILD_MANIFEST = {
  "/": [
    "static/chunks/pages/index.js"
  ],
  "/_error": [
    "static/chunks/pages/_error.js"
  ],
  "/creative-modes": [
    "static/chunks/pages/creative-modes.js"
  ],
  "/tributaries": [
    "static/chunks/pages/tributaries.js"
  ],
  "/trip-details": [
    "static/chunks/pages/trip-details.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/",
    "/_app",
    "/_error",
    "/api/hello",
    "/creative-modes",
    "/itinerary",
    "/style",
    "/tributaries",
    "/trip",
    "/trip-details"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()