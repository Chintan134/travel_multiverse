(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[turbopack]/browser/dev/hmr-client/hmr-client.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/// <reference path="../../../shared/runtime-types.d.ts" />
/// <reference path="../../runtime/base/dev-globals.d.ts" />
/// <reference path="../../runtime/base/dev-protocol.d.ts" />
/// <reference path="../../runtime/base/dev-extensions.ts" />
__turbopack_context__.s([
    "connect",
    ()=>connect,
    "setHooks",
    ()=>setHooks,
    "subscribeToUpdate",
    ()=>subscribeToUpdate
]);
function connect({ addMessageListener, sendMessage, onUpdateError = console.error }) {
    addMessageListener((msg)=>{
        switch(msg.type){
            case 'turbopack-connected':
                handleSocketConnected(sendMessage);
                break;
            default:
                try {
                    if (Array.isArray(msg.data)) {
                        for(let i = 0; i < msg.data.length; i++){
                            handleSocketMessage(msg.data[i]);
                        }
                    } else {
                        handleSocketMessage(msg.data);
                    }
                    applyAggregatedUpdates();
                } catch (e) {
                    console.warn('[Fast Refresh] performing full reload\n\n' + "Fast Refresh will perform a full reload when you edit a file that's imported by modules outside of the React rendering tree.\n" + 'You might have a file which exports a React component but also exports a value that is imported by a non-React component file.\n' + 'Consider migrating the non-React component export to a separate file and importing it into both files.\n\n' + 'It is also possible the parent component of the component you edited is a class component, which disables Fast Refresh.\n' + 'Fast Refresh requires at least one parent function component in your React tree.');
                    onUpdateError(e);
                    location.reload();
                }
                break;
        }
    });
    const queued = globalThis.TURBOPACK_CHUNK_UPDATE_LISTENERS;
    if (queued != null && !Array.isArray(queued)) {
        throw new Error('A separate HMR handler was already registered');
    }
    globalThis.TURBOPACK_CHUNK_UPDATE_LISTENERS = {
        push: ([chunkPath, callback])=>{
            subscribeToChunkUpdate(chunkPath, sendMessage, callback);
        }
    };
    if (Array.isArray(queued)) {
        for (const [chunkPath, callback] of queued){
            subscribeToChunkUpdate(chunkPath, sendMessage, callback);
        }
    }
}
const updateCallbackSets = new Map();
function sendJSON(sendMessage, message) {
    sendMessage(JSON.stringify(message));
}
function resourceKey(resource) {
    return JSON.stringify({
        path: resource.path,
        headers: resource.headers || null
    });
}
function subscribeToUpdates(sendMessage, resource) {
    sendJSON(sendMessage, {
        type: 'turbopack-subscribe',
        ...resource
    });
    return ()=>{
        sendJSON(sendMessage, {
            type: 'turbopack-unsubscribe',
            ...resource
        });
    };
}
function handleSocketConnected(sendMessage) {
    for (const key of updateCallbackSets.keys()){
        subscribeToUpdates(sendMessage, JSON.parse(key));
    }
}
// we aggregate all pending updates until the issues are resolved
const chunkListsWithPendingUpdates = new Map();
function aggregateUpdates(msg) {
    const key = resourceKey(msg.resource);
    let aggregated = chunkListsWithPendingUpdates.get(key);
    if (aggregated) {
        aggregated.instruction = mergeChunkListUpdates(aggregated.instruction, msg.instruction);
    } else {
        chunkListsWithPendingUpdates.set(key, msg);
    }
}
function applyAggregatedUpdates() {
    if (chunkListsWithPendingUpdates.size === 0) return;
    hooks.beforeRefresh();
    for (const msg of chunkListsWithPendingUpdates.values()){
        triggerUpdate(msg);
    }
    chunkListsWithPendingUpdates.clear();
    finalizeUpdate();
}
function mergeChunkListUpdates(updateA, updateB) {
    let chunks;
    if (updateA.chunks != null) {
        if (updateB.chunks == null) {
            chunks = updateA.chunks;
        } else {
            chunks = mergeChunkListChunks(updateA.chunks, updateB.chunks);
        }
    } else if (updateB.chunks != null) {
        chunks = updateB.chunks;
    }
    let merged;
    if (updateA.merged != null) {
        if (updateB.merged == null) {
            merged = updateA.merged;
        } else {
            // Since `merged` is an array of updates, we need to merge them all into
            // one, consistent update.
            // Since there can only be `EcmascriptMergeUpdates` in the array, there is
            // no need to key on the `type` field.
            let update = updateA.merged[0];
            for(let i = 1; i < updateA.merged.length; i++){
                update = mergeChunkListEcmascriptMergedUpdates(update, updateA.merged[i]);
            }
            for(let i = 0; i < updateB.merged.length; i++){
                update = mergeChunkListEcmascriptMergedUpdates(update, updateB.merged[i]);
            }
            merged = [
                update
            ];
        }
    } else if (updateB.merged != null) {
        merged = updateB.merged;
    }
    return {
        type: 'ChunkListUpdate',
        chunks,
        merged
    };
}
function mergeChunkListChunks(chunksA, chunksB) {
    const chunks = {};
    for (const [chunkPath, chunkUpdateA] of Object.entries(chunksA)){
        const chunkUpdateB = chunksB[chunkPath];
        if (chunkUpdateB != null) {
            const mergedUpdate = mergeChunkUpdates(chunkUpdateA, chunkUpdateB);
            if (mergedUpdate != null) {
                chunks[chunkPath] = mergedUpdate;
            }
        } else {
            chunks[chunkPath] = chunkUpdateA;
        }
    }
    for (const [chunkPath, chunkUpdateB] of Object.entries(chunksB)){
        if (chunks[chunkPath] == null) {
            chunks[chunkPath] = chunkUpdateB;
        }
    }
    return chunks;
}
function mergeChunkUpdates(updateA, updateB) {
    if (updateA.type === 'added' && updateB.type === 'deleted' || updateA.type === 'deleted' && updateB.type === 'added') {
        return undefined;
    }
    if (updateA.type === 'partial') {
        invariant(updateA.instruction, 'Partial updates are unsupported');
    }
    if (updateB.type === 'partial') {
        invariant(updateB.instruction, 'Partial updates are unsupported');
    }
    return undefined;
}
function mergeChunkListEcmascriptMergedUpdates(mergedA, mergedB) {
    const entries = mergeEcmascriptChunkEntries(mergedA.entries, mergedB.entries);
    const chunks = mergeEcmascriptChunksUpdates(mergedA.chunks, mergedB.chunks);
    return {
        type: 'EcmascriptMergedUpdate',
        entries,
        chunks
    };
}
function mergeEcmascriptChunkEntries(entriesA, entriesB) {
    return {
        ...entriesA,
        ...entriesB
    };
}
function mergeEcmascriptChunksUpdates(chunksA, chunksB) {
    if (chunksA == null) {
        return chunksB;
    }
    if (chunksB == null) {
        return chunksA;
    }
    const chunks = {};
    for (const [chunkPath, chunkUpdateA] of Object.entries(chunksA)){
        const chunkUpdateB = chunksB[chunkPath];
        if (chunkUpdateB != null) {
            const mergedUpdate = mergeEcmascriptChunkUpdates(chunkUpdateA, chunkUpdateB);
            if (mergedUpdate != null) {
                chunks[chunkPath] = mergedUpdate;
            }
        } else {
            chunks[chunkPath] = chunkUpdateA;
        }
    }
    for (const [chunkPath, chunkUpdateB] of Object.entries(chunksB)){
        if (chunks[chunkPath] == null) {
            chunks[chunkPath] = chunkUpdateB;
        }
    }
    if (Object.keys(chunks).length === 0) {
        return undefined;
    }
    return chunks;
}
function mergeEcmascriptChunkUpdates(updateA, updateB) {
    if (updateA.type === 'added' && updateB.type === 'deleted') {
        // These two completely cancel each other out.
        return undefined;
    }
    if (updateA.type === 'deleted' && updateB.type === 'added') {
        const added = [];
        const deleted = [];
        const deletedModules = new Set(updateA.modules ?? []);
        const addedModules = new Set(updateB.modules ?? []);
        for (const moduleId of addedModules){
            if (!deletedModules.has(moduleId)) {
                added.push(moduleId);
            }
        }
        for (const moduleId of deletedModules){
            if (!addedModules.has(moduleId)) {
                deleted.push(moduleId);
            }
        }
        if (added.length === 0 && deleted.length === 0) {
            return undefined;
        }
        return {
            type: 'partial',
            added,
            deleted
        };
    }
    if (updateA.type === 'partial' && updateB.type === 'partial') {
        const added = new Set([
            ...updateA.added ?? [],
            ...updateB.added ?? []
        ]);
        const deleted = new Set([
            ...updateA.deleted ?? [],
            ...updateB.deleted ?? []
        ]);
        if (updateB.added != null) {
            for (const moduleId of updateB.added){
                deleted.delete(moduleId);
            }
        }
        if (updateB.deleted != null) {
            for (const moduleId of updateB.deleted){
                added.delete(moduleId);
            }
        }
        return {
            type: 'partial',
            added: [
                ...added
            ],
            deleted: [
                ...deleted
            ]
        };
    }
    if (updateA.type === 'added' && updateB.type === 'partial') {
        const modules = new Set([
            ...updateA.modules ?? [],
            ...updateB.added ?? []
        ]);
        for (const moduleId of updateB.deleted ?? []){
            modules.delete(moduleId);
        }
        return {
            type: 'added',
            modules: [
                ...modules
            ]
        };
    }
    if (updateA.type === 'partial' && updateB.type === 'deleted') {
        // We could eagerly return `updateB` here, but this would potentially be
        // incorrect if `updateA` has added modules.
        const modules = new Set(updateB.modules ?? []);
        if (updateA.added != null) {
            for (const moduleId of updateA.added){
                modules.delete(moduleId);
            }
        }
        return {
            type: 'deleted',
            modules: [
                ...modules
            ]
        };
    }
    // Any other update combination is invalid.
    return undefined;
}
function invariant(_, message) {
    throw new Error(`Invariant: ${message}`);
}
const CRITICAL = [
    'bug',
    'error',
    'fatal'
];
function compareByList(list, a, b) {
    const aI = list.indexOf(a) + 1 || list.length;
    const bI = list.indexOf(b) + 1 || list.length;
    return aI - bI;
}
const chunksWithIssues = new Map();
function emitIssues() {
    const issues = [];
    const deduplicationSet = new Set();
    for (const [_, chunkIssues] of chunksWithIssues){
        for (const chunkIssue of chunkIssues){
            if (deduplicationSet.has(chunkIssue.formatted)) continue;
            issues.push(chunkIssue);
            deduplicationSet.add(chunkIssue.formatted);
        }
    }
    sortIssues(issues);
    hooks.issues(issues);
}
function handleIssues(msg) {
    const key = resourceKey(msg.resource);
    let hasCriticalIssues = false;
    for (const issue of msg.issues){
        if (CRITICAL.includes(issue.severity)) {
            hasCriticalIssues = true;
        }
    }
    if (msg.issues.length > 0) {
        chunksWithIssues.set(key, msg.issues);
    } else if (chunksWithIssues.has(key)) {
        chunksWithIssues.delete(key);
    }
    emitIssues();
    return hasCriticalIssues;
}
const SEVERITY_ORDER = [
    'bug',
    'fatal',
    'error',
    'warning',
    'info',
    'log'
];
const CATEGORY_ORDER = [
    'parse',
    'resolve',
    'code generation',
    'rendering',
    'typescript',
    'other'
];
function sortIssues(issues) {
    issues.sort((a, b)=>{
        const first = compareByList(SEVERITY_ORDER, a.severity, b.severity);
        if (first !== 0) return first;
        return compareByList(CATEGORY_ORDER, a.category, b.category);
    });
}
const hooks = {
    beforeRefresh: ()=>{},
    refresh: ()=>{},
    buildOk: ()=>{},
    issues: (_issues)=>{}
};
function setHooks(newHooks) {
    Object.assign(hooks, newHooks);
}
function handleSocketMessage(msg) {
    sortIssues(msg.issues);
    handleIssues(msg);
    switch(msg.type){
        case 'issues':
            break;
        case 'partial':
            // aggregate updates
            aggregateUpdates(msg);
            break;
        default:
            // run single update
            const runHooks = chunkListsWithPendingUpdates.size === 0;
            if (runHooks) hooks.beforeRefresh();
            triggerUpdate(msg);
            if (runHooks) finalizeUpdate();
            break;
    }
}
function finalizeUpdate() {
    hooks.refresh();
    hooks.buildOk();
    // This is used by the Next.js integration test suite to notify it when HMR
    // updates have been completed.
    // TODO: Only run this in test environments (gate by `process.env.__NEXT_TEST_MODE`)
    if (globalThis.__NEXT_HMR_CB) {
        globalThis.__NEXT_HMR_CB();
        globalThis.__NEXT_HMR_CB = null;
    }
}
function subscribeToChunkUpdate(chunkListPath, sendMessage, callback) {
    return subscribeToUpdate({
        path: chunkListPath
    }, sendMessage, callback);
}
function subscribeToUpdate(resource, sendMessage, callback) {
    const key = resourceKey(resource);
    let callbackSet;
    const existingCallbackSet = updateCallbackSets.get(key);
    if (!existingCallbackSet) {
        callbackSet = {
            callbacks: new Set([
                callback
            ]),
            unsubscribe: subscribeToUpdates(sendMessage, resource)
        };
        updateCallbackSets.set(key, callbackSet);
    } else {
        existingCallbackSet.callbacks.add(callback);
        callbackSet = existingCallbackSet;
    }
    return ()=>{
        callbackSet.callbacks.delete(callback);
        if (callbackSet.callbacks.size === 0) {
            callbackSet.unsubscribe();
            updateCallbackSets.delete(key);
        }
    };
}
function triggerUpdate(msg) {
    const key = resourceKey(msg.resource);
    const callbackSet = updateCallbackSets.get(key);
    if (!callbackSet) {
        return;
    }
    for (const callback of callbackSet.callbacks){
        callback(msg);
    }
    if (msg.type === 'notFound') {
        // This indicates that the resource which we subscribed to either does not exist or
        // has been deleted. In either case, we should clear all update callbacks, so if a
        // new subscription is created for the same resource, it will send a new "subscribe"
        // message to the server.
        // No need to send an "unsubscribe" message to the server, it will have already
        // dropped the update stream before sending the "notFound" message.
        updateCallbackSets.delete(key);
    }
}
}),
"[project]/styles/Home.module.css [client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "continueButton": "Home-module__g21JLG__continueButton",
  "creativeContinueButton": "Home-module__g21JLG__creativeContinueButton",
  "creativeCtaRow": "Home-module__g21JLG__creativeCtaRow",
  "creativeFlavorCard": "Home-module__g21JLG__creativeFlavorCard",
  "creativeFlavorCardActive": "Home-module__g21JLG__creativeFlavorCardActive",
  "creativeFlavorCardInactive": "Home-module__g21JLG__creativeFlavorCardInactive",
  "creativeFlavorDescription": "Home-module__g21JLG__creativeFlavorDescription",
  "creativeFlavorIcon": "Home-module__g21JLG__creativeFlavorIcon",
  "creativeFlavorText": "Home-module__g21JLG__creativeFlavorText",
  "creativeFlavorTitle": "Home-module__g21JLG__creativeFlavorTitle",
  "creativeFlavorsGrid": "Home-module__g21JLG__creativeFlavorsGrid",
  "creativeFlavorsHeader": "Home-module__g21JLG__creativeFlavorsHeader",
  "creativeFlavorsRow": "Home-module__g21JLG__creativeFlavorsRow",
  "creativeFlavorsSubtitle": "Home-module__g21JLG__creativeFlavorsSubtitle",
  "creativeFlavorsTitle": "Home-module__g21JLG__creativeFlavorsTitle",
  "creativeSelectedText": "Home-module__g21JLG__creativeSelectedText",
  "flavorDetailChip": "Home-module__g21JLG__flavorDetailChip",
  "flavorDetailChipActive": "Home-module__g21JLG__flavorDetailChipActive",
  "flavorDetailChipInactive": "Home-module__g21JLG__flavorDetailChipInactive",
  "flavorDetailChips": "Home-module__g21JLG__flavorDetailChips",
  "flavorDetailFileInput": "Home-module__g21JLG__flavorDetailFileInput",
  "flavorDetailHeader": "Home-module__g21JLG__flavorDetailHeader",
  "flavorDetailHint": "Home-module__g21JLG__flavorDetailHint",
  "flavorDetailInfo": "Home-module__g21JLG__flavorDetailInfo",
  "flavorDetailPanel": "Home-module__g21JLG__flavorDetailPanel",
  "flavorDetailSubtitle": "Home-module__g21JLG__flavorDetailSubtitle",
  "flavorDetailTitle": "Home-module__g21JLG__flavorDetailTitle",
  "flavorDetailUpload": "Home-module__g21JLG__flavorDetailUpload",
  "header": "Home-module__g21JLG__header",
  "headerTagline": "Home-module__g21JLG__headerTagline",
  "hero": "Home-module__g21JLG__hero",
  "heroButton": "Home-module__g21JLG__heroButton",
  "heroContent": "Home-module__g21JLG__heroContent",
  "heroNote": "Home-module__g21JLG__heroNote",
  "heroOverlay": "Home-module__g21JLG__heroOverlay",
  "heroSubline": "Home-module__g21JLG__heroSubline",
  "heroTagline": "Home-module__g21JLG__heroTagline",
  "heroTitle": "Home-module__g21JLG__heroTitle",
  "itineraryDay": "Home-module__g21JLG__itineraryDay",
  "itineraryDayMarker": "Home-module__g21JLG__itineraryDayMarker",
  "itineraryDayTitle": "Home-module__g21JLG__itineraryDayTitle",
  "itineraryItem": "Home-module__g21JLG__itineraryItem",
  "itineraryItemList": "Home-module__g21JLG__itineraryItemList",
  "logo": "Home-module__g21JLG__logo",
  "logoWrapper": "Home-module__g21JLG__logoWrapper",
  "multiverseTab": "Home-module__g21JLG__multiverseTab",
  "multiverseTabActive": "Home-module__g21JLG__multiverseTabActive",
  "multiverseTabs": "Home-module__g21JLG__multiverseTabs",
  "page": "Home-module__g21JLG__page",
  "summaryActions": "Home-module__g21JLG__summaryActions",
  "summaryButtonGhost": "Home-module__g21JLG__summaryButtonGhost",
  "summaryButtonPrimary": "Home-module__g21JLG__summaryButtonPrimary",
  "summaryButtonSecondary": "Home-module__g21JLG__summaryButtonSecondary",
  "summaryCard": "Home-module__g21JLG__summaryCard",
  "summaryCardTitle": "Home-module__g21JLG__summaryCardTitle",
  "summaryGrid": "Home-module__g21JLG__summaryGrid",
  "summaryHero": "Home-module__g21JLG__summaryHero",
  "summaryHeroChip": "Home-module__g21JLG__summaryHeroChip",
  "summaryHeroChips": "Home-module__g21JLG__summaryHeroChips",
  "summaryHeroContent": "Home-module__g21JLG__summaryHeroContent",
  "summaryHeroOverlay": "Home-module__g21JLG__summaryHeroOverlay",
  "summaryHeroQuote": "Home-module__g21JLG__summaryHeroQuote",
  "summaryHeroTagline": "Home-module__g21JLG__summaryHeroTagline",
  "summaryHeroTitle": "Home-module__g21JLG__summaryHeroTitle",
  "summaryIntro": "Home-module__g21JLG__summaryIntro",
  "summaryItineraryCard": "Home-module__g21JLG__summaryItineraryCard",
  "summaryModeStrip": "Home-module__g21JLG__summaryModeStrip",
  "summaryModeStripLabel": "Home-module__g21JLG__summaryModeStripLabel",
  "summaryModeStripText": "Home-module__g21JLG__summaryModeStripText",
  "summaryTimelineTitle": "Home-module__g21JLG__summaryTimelineTitle",
  "tripBackLink": "Home-module__g21JLG__tripBackLink",
  "tripBackRow": "Home-module__g21JLG__tripBackRow",
  "tripBadge": "Home-module__g21JLG__tripBadge",
  "tripButtonPrimary": "Home-module__g21JLG__tripButtonPrimary",
  "tripButtonSecondary": "Home-module__g21JLG__tripButtonSecondary",
  "tripCard": "Home-module__g21JLG__tripCard",
  "tripCardActive": "Home-module__g21JLG__tripCardActive",
  "tripCardHeaderRow": "Home-module__g21JLG__tripCardHeaderRow",
  "tripCardInactive": "Home-module__g21JLG__tripCardInactive",
  "tripCardSubtitle": "Home-module__g21JLG__tripCardSubtitle",
  "tripCardTitle": "Home-module__g21JLG__tripCardTitle",
  "tripContainer": "Home-module__g21JLG__tripContainer",
  "tripFieldGroup": "Home-module__g21JLG__tripFieldGroup",
  "tripFormGrid": "Home-module__g21JLG__tripFormGrid",
  "tripHint": "Home-module__g21JLG__tripHint",
  "tripInput": "Home-module__g21JLG__tripInput",
  "tripLabel": "Home-module__g21JLG__tripLabel",
  "tripMain": "Home-module__g21JLG__tripMain",
  "tripNote": "Home-module__g21JLG__tripNote",
  "tripOptionsLayout": "Home-module__g21JLG__tripOptionsLayout",
  "tripSelect": "Home-module__g21JLG__tripSelect",
  "tripSubtitle": "Home-module__g21JLG__tripSubtitle",
  "tripTextarea": "Home-module__g21JLG__tripTextarea",
  "tripTitle": "Home-module__g21JLG__tripTitle",
  "video": "Home-module__g21JLG__video",
  "videoDescription": "Home-module__g21JLG__videoDescription",
  "videoEyebrow": "Home-module__g21JLG__videoEyebrow",
  "videoSection": "Home-module__g21JLG__videoSection",
  "videoText": "Home-module__g21JLG__videoText",
  "videoTitle": "Home-module__g21JLG__videoTitle",
  "videoWrapper": "Home-module__g21JLG__videoWrapper",
});
}),
"[project]/pages/tributaries.js [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// pages/tributaries.js
__turbopack_context__.s([
    "default",
    ()=>TributariesSummary
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$head$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/head.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/router.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/styles/Home.module.css [client] (css module)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
// Static hero background: vibrant image + soft gradient
function getHeroBackground() {
    return "linear-gradient(to bottom right,rgba(15,23,42,0.1),rgba(15,23,42,0.9)), url('/hero.jpg')";
}
function getModeLabel(mode, flavor) {
    const m = (mode || "").toLowerCase();
    const f = (flavor || "").toLowerCase();
    if (m === "classic") return "Classic Itinerary";
    if (f === "vibetrip") return "VibeTrip";
    if (f === "parallel") return "Parallel Universe Trip";
    if (f === "onephoto") return "One Photo → One Trip";
    if (f === "multiverse") return "Multiverse Generator";
    if (f === "antiitinerary") return "Anti-Itinerary";
    return "Creative Multiverse Mode";
}
function getModeNote({ mode, flavor, detail }) {
    const m = (mode || "").toLowerCase();
    const f = (flavor || "").toLowerCase();
    if (m === "classic") {
        return "You chose Classic Mode, so this itinerary focuses on a clean, logical flow with reliable time blocks and essential highlights.";
    }
    if (f === "vibetrip") {
        const mood = detail || "your selected mood";
        return `Your mood was ${mood}, so this itinerary leans into neighborhoods, time slots, and experiences that reflect that emotional tone.`;
    }
    if (f === "parallel") {
        const persona = detail || "your chosen persona";
        return `As ${persona}, this trip emphasizes bold, character-driven choices that version of you would naturally make.`;
    }
    if (f === "onephoto") {
        const ref = detail ? `the image “${detail}”` : "your uploaded image";
        return `The colors and feel of ${ref} inspired the aesthetic and pacing of this journey.`;
    }
    if (f === "multiverse") {
        return "You unlocked three parallel versions of the same destination — realistic, dream/unlimited, and vibe/cinematic. Switch between them like timelines.";
    }
    if (f === "antiitinerary") {
        return "You selected Anti-Itinerary mode, so the plan acts as light guidance only. The real magic comes from wandering, curiosity, and happy accidents.";
    }
    return "";
}
// Build up to 14 days, so long trips still look smooth.
function buildSingleItinerary(daysCount) {
    const baseDays = [
        [
            "Arrive and take a gentle orientation walk.",
            "Visit a calm sunset viewpoint.",
            "Dinner at a cozy local spot."
        ],
        [
            "Visit a major landmark in the morning.",
            "Explore hidden alleys or a local market.",
            "Evening at a recommended café or bar."
        ],
        [
            "Morning walk through a peaceful district.",
            "Pick up meaningful souvenirs.",
            "Relax with a waterfront or rooftop sunset."
        ]
    ];
    const count = Math.max(1, Math.min(14, Number(daysCount) || 3));
    const days = [];
    for(let i = 0; i < count; i++){
        days.push({
            title: `Day ${i + 1}`,
            items: baseDays[i] || [
                "Explore freely at your own pace.",
                "Follow spontaneous discoveries or local tips.",
                "End the day with reflection and a relaxed meal."
            ]
        });
    }
    return days;
}
function buildMultiverseItinerary(daysCount) {
    const base = buildSingleItinerary(daysCount);
    const tweak = (suffix)=>base.map((day)=>({
                title: day.title,
                items: day.items.map((item)=>`${item} (${suffix})`)
            }));
    return {
        realistic: tweak("realistic"),
        dream: tweak("dream / unlimited"),
        vibe: tweak("vibe / cinematic")
    };
}
function TributariesSummary() {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [openTimeline, setOpenTimeline] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])("realistic");
    const query = router.query || {};
    // Raw values from query (to detect if user actually provided them)
    const rawDestination = query.destination || "";
    const rawDays = query.days || "";
    const rawCompanion = query.companion || "";
    const rawMode = query.mode || "";
    const rawFlavor = query.flavor || "";
    const rawDetail = query.detail || "";
    const mode = rawMode || "classic";
    const flavor = rawFlavor || "";
    const detail = rawDetail || "";
    // Safe values with fallbacks for display / logic
    const destination = rawDestination || "Your Destination";
    const duration = rawDays || "3";
    const companion = rawCompanion || "Solo";
    const isMultiverse = String(flavor).toLowerCase() === "multiverse" && String(mode).toLowerCase() !== "classic";
    const itineraries = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "TributariesSummary.useMemo[itineraries]": ()=>isMultiverse ? buildMultiverseItinerary(duration) : buildSingleItinerary(duration)
    }["TributariesSummary.useMemo[itineraries]"], [
        isMultiverse,
        duration
    ]);
    const modeLabel = getModeLabel(mode, flavor);
    const modeDisplay = detail ? `${modeLabel} — ${detail}` : modeLabel;
    const heroBackground = getHeroBackground();
    const specialNote = getModeNote({
        mode,
        flavor,
        detail
    });
    const handlePdf = ()=>{
        if ("TURBOPACK compile-time truthy", 1) {
            window.print(); // browser → Save as PDF
        }
    };
    const handleRegenerate = ()=>router.replace({
            pathname: "/tributaries",
            query: {
                ...query,
                rev: Date.now()
            }
        });
    const handleEdit = ()=>router.push({
            pathname: "/trip-details",
            query
        });
    const handleNew = ()=>router.push("/");
    const durationNumber = Number(duration) || 0;
    const durationLabel = durationNumber > 0 ? `${durationNumber} day${durationNumber > 1 ? "s" : ""}` : "Flexible length";
    // For overview text
    const overviewParts = [];
    if (rawDestination) overviewParts.push(`to ${destination}`);
    if (durationNumber > 0 && rawDays) overviewParts.push(`for ${durationLabel}`);
    if (rawCompanion) overviewParts.push(`with ${companion.toLowerCase()}`);
    if (rawMode || rawFlavor || rawDetail) overviewParts.push(`in ${modeDisplay} mode`);
    const overviewSentence = overviewParts.length > 0 ? `A ${overviewParts.join(" ")}.` : "A personalized journey shaped around your preferences.";
    // Dynamic chip visibility (only show if user provided that piece)
    const showDestinationChip = !!rawDestination;
    const showDaysChip = !!rawDays;
    const showCompanionChip = !!rawCompanion;
    const showModeChip = !!(rawMode || rawFlavor || rawDetail);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].page,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$head$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("title", {
                    children: "Your Trip | Travel Multiverse"
                }, void 0, false, {
                    fileName: "[project]/pages/tributaries.js",
                    lineNumber: 191,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/pages/tributaries.js",
                lineNumber: 190,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].tripMain,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].tripContainer,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].summaryHero,
                            style: {
                                backgroundImage: heroBackground
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].summaryHeroOverlay
                                }, void 0, false, {
                                    fileName: "[project]/pages/tributaries.js",
                                    lineNumber: 203,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].summaryHeroContent,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].summaryHeroTagline,
                                            children: "AI-CRAFTED TRAVEL STORY"
                                        }, void 0, false, {
                                            fileName: "[project]/pages/tributaries.js",
                                            lineNumber: 205,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].summaryHeroTitle,
                                            children: [
                                                "Trip to ",
                                                destination
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/pages/tributaries.js",
                                            lineNumber: 208,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].summaryHeroChips,
                                            children: [
                                                showDestinationChip && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].summaryHeroChip,
                                                    children: [
                                                        "Destination: ",
                                                        destination
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/pages/tributaries.js",
                                                    lineNumber: 214,
                                                    columnNumber: 19
                                                }, this),
                                                showDaysChip && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].summaryHeroChip,
                                                    children: [
                                                        "Duration: ",
                                                        durationLabel
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/pages/tributaries.js",
                                                    lineNumber: 219,
                                                    columnNumber: 19
                                                }, this),
                                                showCompanionChip && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].summaryHeroChip,
                                                    children: [
                                                        "Companion: ",
                                                        companion
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/pages/tributaries.js",
                                                    lineNumber: 224,
                                                    columnNumber: 19
                                                }, this),
                                                showModeChip && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].summaryHeroChip,
                                                    children: [
                                                        "Mode: ",
                                                        modeDisplay
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/pages/tributaries.js",
                                                    lineNumber: 229,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/pages/tributaries.js",
                                            lineNumber: 212,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].summaryHeroQuote,
                                            children: "“Trips change places. Great trips change people. Your story begins now — enjoy the journey.”"
                                        }, void 0, false, {
                                            fileName: "[project]/pages/tributaries.js",
                                            lineNumber: 235,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/pages/tributaries.js",
                                    lineNumber: 204,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/pages/tributaries.js",
                            lineNumber: 199,
                            columnNumber: 11
                        }, this),
                        specialNote && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].summaryModeStrip,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].summaryModeStripLabel,
                                    children: "Special Mode Notes"
                                }, void 0, false, {
                                    fileName: "[project]/pages/tributaries.js",
                                    lineNumber: 245,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].summaryModeStripText,
                                    children: specialNote
                                }, void 0, false, {
                                    fileName: "[project]/pages/tributaries.js",
                                    lineNumber: 248,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/pages/tributaries.js",
                            lineNumber: 244,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: `${__TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].summaryCard} ${__TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].summaryItineraryCard}`,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].summaryTimelineTitle,
                                    children: "Your Trip Timeline"
                                }, void 0, false, {
                                    fileName: "[project]/pages/tributaries.js",
                                    lineNumber: 256,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].summaryIntro,
                                    children: overviewSentence
                                }, void 0, false, {
                                    fileName: "[project]/pages/tributaries.js",
                                    lineNumber: 257,
                                    columnNumber: 13
                                }, this),
                                isMultiverse && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].multiverseTabs,
                                    children: [
                                        "realistic",
                                        "dream",
                                        "vibe"
                                    ].map((key)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            className: `${__TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].multiverseTab} ${openTimeline === key ? __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].multiverseTabActive : ""}`,
                                            onClick: ()=>setOpenTimeline(key),
                                            children: [
                                                key === "realistic" && "Realistic",
                                                key === "dream" && "Dream / Unlimited",
                                                key === "vibe" && "Vibe / Cinematic"
                                            ]
                                        }, key, true, {
                                            fileName: "[project]/pages/tributaries.js",
                                            lineNumber: 262,
                                            columnNumber: 19
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/pages/tributaries.js",
                                    lineNumber: 260,
                                    columnNumber: 15
                                }, this),
                                (isMultiverse ? itineraries[openTimeline] || [] : itineraries || []).map((day)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].itineraryDay,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].itineraryDayMarker
                                            }, void 0, false, {
                                                fileName: "[project]/pages/tributaries.js",
                                                lineNumber: 283,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].itineraryDayTitle,
                                                        children: day.title
                                                    }, void 0, false, {
                                                        fileName: "[project]/pages/tributaries.js",
                                                        lineNumber: 285,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].itineraryItemList,
                                                        children: day.items.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].itineraryItem,
                                                                children: item
                                                            }, index, false, {
                                                                fileName: "[project]/pages/tributaries.js",
                                                                lineNumber: 288,
                                                                columnNumber: 23
                                                            }, this))
                                                    }, void 0, false, {
                                                        fileName: "[project]/pages/tributaries.js",
                                                        lineNumber: 286,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/pages/tributaries.js",
                                                lineNumber: 284,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, day.title, true, {
                                        fileName: "[project]/pages/tributaries.js",
                                        lineNumber: 282,
                                        columnNumber: 15
                                    }, this))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/pages/tributaries.js",
                            lineNumber: 253,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].summaryActions,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].summaryButtonPrimary,
                                    onClick: handlePdf,
                                    children: "📄 Download PDF"
                                }, void 0, false, {
                                    fileName: "[project]/pages/tributaries.js",
                                    lineNumber: 300,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].summaryButtonSecondary,
                                    onClick: handleRegenerate,
                                    children: "🔄 Regenerate"
                                }, void 0, false, {
                                    fileName: "[project]/pages/tributaries.js",
                                    lineNumber: 307,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].summaryButtonSecondary,
                                    onClick: handleEdit,
                                    children: "✏️ Edit Trip"
                                }, void 0, false, {
                                    fileName: "[project]/pages/tributaries.js",
                                    lineNumber: 314,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$styles$2f$Home$2e$module$2e$css__$5b$client$5d$__$28$css__module$29$__["default"].summaryButtonGhost,
                                    onClick: handleNew,
                                    children: "🏠 Plan Another Trip"
                                }, void 0, false, {
                                    fileName: "[project]/pages/tributaries.js",
                                    lineNumber: 321,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/pages/tributaries.js",
                            lineNumber: 299,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/pages/tributaries.js",
                    lineNumber: 197,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/pages/tributaries.js",
                lineNumber: 196,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/pages/tributaries.js",
        lineNumber: 189,
        columnNumber: 5
    }, this);
}
_s(TributariesSummary, "cSKqE8mLYHdR0IjCfMSqZAqk2OE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = TributariesSummary;
var _c;
__turbopack_context__.k.register(_c, "TributariesSummary");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[next]/entry/page-loader.ts { PAGE => \"[project]/pages/tributaries.js [client] (ecmascript)\" } [client] (ecmascript)", ((__turbopack_context__, module, exports) => {

const PAGE_PATH = "/tributaries";
(window.__NEXT_P = window.__NEXT_P || []).push([
    PAGE_PATH,
    ()=>{
        return __turbopack_context__.r("[project]/pages/tributaries.js [client] (ecmascript)");
    }
]);
// @ts-expect-error module.hot exists
if (module.hot) {
    // @ts-expect-error module.hot exists
    module.hot.dispose(function() {
        window.__NEXT_P.push([
            PAGE_PATH
        ]);
    });
}
}),
"[hmr-entry]/hmr-entry.js { ENTRY => \"[project]/pages/tributaries\" }", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.r("[next]/entry/page-loader.ts { PAGE => \"[project]/pages/tributaries.js [client] (ecmascript)\" } [client] (ecmascript)");
}),
]);

//# sourceMappingURL=%5Broot-of-the-server%5D__127fc4d8._.js.map